﻿export enum Role {
    SPRADM = 'SPRADM',
    OADM = 'OADM',
    RADM = 'RADM'
}