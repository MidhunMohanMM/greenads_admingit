import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blocknumbers',
  templateUrl: './blocknumbers.component.html',
  styleUrls: ['./blocknumbers.component.css']
})
export class BlocknumbersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
