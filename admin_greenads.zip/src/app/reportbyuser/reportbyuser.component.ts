import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportbyuser',
  templateUrl: './reportbyuser.component.html',
  styleUrls: ['./reportbyuser.component.css']
})
export class ReportbyuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
