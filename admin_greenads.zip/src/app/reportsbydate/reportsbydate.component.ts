import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportsbydate',
  templateUrl: './reportsbydate.component.html',
  styleUrls: ['./reportsbydate.component.css']
})
export class ReportsbydateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
