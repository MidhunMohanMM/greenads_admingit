import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportsbyroutes',
  templateUrl: './reportsbyroutes.component.html',
  styleUrls: ['./reportsbyroutes.component.css']
})
export class ReportsbyroutesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
