import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-routegateway',
  templateUrl: './routegateway.component.html',
  styleUrls: ['./routegateway.component.css']
})
export class RoutegatewayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
