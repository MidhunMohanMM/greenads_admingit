import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smpplog',
  templateUrl: './smpplog.component.html',
  styleUrls: ['./smpplog.component.css']
})
export class SmpplogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
