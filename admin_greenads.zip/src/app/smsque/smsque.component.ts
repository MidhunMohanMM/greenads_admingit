import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smsque',
  templateUrl: './smsque.component.html',
  styleUrls: ['./smsque.component.css']
})
export class SmsqueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
