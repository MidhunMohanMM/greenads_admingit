import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-totalpayment',
  templateUrl: './totalpayment.component.html',
  styleUrls: ['./totalpayment.component.css']
})
export class TotalpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
