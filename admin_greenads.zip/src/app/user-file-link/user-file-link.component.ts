import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-file-link',
  templateUrl: './user-file-link.component.html',
  styleUrls: ['./user-file-link.component.css']
})
export class UserFileLinkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
